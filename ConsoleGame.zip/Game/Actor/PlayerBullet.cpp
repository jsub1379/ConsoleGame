#include "PlayerBullet.h"
#include "Engine.h"

#include "Input.h"
#include "Level/Level.h"


PlayerBullet::PlayerBullet(const Vector2& position, const Vector2& direction)
    : Actor('-', Color::White, position) // �Ѿ� ����� '-'
{
    SetSortingOrder(2); // �÷��̾�� �Ʒ� ����
    direction == Vector2::Zero;
    xPosition = (float)position.x;
    yPosition = (float)position.y;
}

void PlayerBullet::Tick(float deltaTime)
{
    super::Tick(deltaTime);
    // �̵�
    xPosition += direction.x* speed* deltaTime;
    yPosition += direction.y * speed * deltaTime;
    SetPosition(Vector2((int)xPosition, (int)yPosition));
    // ȭ�� ���̸� ����
    if (position.x >= 30)
    {
        Destroy();
    }
}
