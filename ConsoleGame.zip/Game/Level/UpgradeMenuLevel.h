#pragma once
#include "MenuLevel.h"

class UpgradeMenuLevel : public MenuLevel
{
    RTTI_DECLARATIONS(UpgradeMenuLevel, MenuLevel)

public:
    UpgradeMenuLevel();
    ~UpgradeMenuLevel();

};
