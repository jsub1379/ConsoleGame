#pragma once
#include "MenuLevel.h"

class EscMenuLevel : public MenuLevel
{
    RTTI_DECLARATIONS(EscMenuLevel, MenuLevel)

public:
    EscMenuLevel();
    ~EscMenuLevel();

};
